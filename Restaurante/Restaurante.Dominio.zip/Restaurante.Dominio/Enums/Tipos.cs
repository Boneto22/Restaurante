using System;

namespace Restaurante.Dominio { 
    public enum Tipos { 
        Cocinero, 
        Cajero, 
        Mesero,
        Facturador,
        Ayudante,
        Administrador
    
       
    }
}