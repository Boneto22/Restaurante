using System;

namespace Restaurante.Dominio {

    public class Mesa { 
      public  int id {get; set;}
      public  string descripcion {get; set;}
      public  string ubicacion {get; set;}

    }
}