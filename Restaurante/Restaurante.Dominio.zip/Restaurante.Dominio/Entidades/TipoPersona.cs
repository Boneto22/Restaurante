using System;

namespace Restaurante.Dominio { 
    
    public class TipoPersona { 
      public  int id {get; set;}
      public  int idpersona {get; set;}
      public  string tipoP {get; set;}

    } 

}