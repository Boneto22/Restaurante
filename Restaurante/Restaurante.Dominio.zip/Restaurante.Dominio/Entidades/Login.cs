using System;

namespace Restaurante.Dominio { 
  
    public class Login  { 
      public  int id {get; set;}
      public  string password {get; set;}
      public  Rol idRol {get; set;}
    }
}